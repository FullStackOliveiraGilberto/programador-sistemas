package controller;

import util.Teclado;

public class desviocondicionalcomposto {

	public static void main(String[] args) {
		int a,b,x;
		a = Teclado.Lerint("Informe o primeiro numero");
		b = Teclado.Lerint("Informe o segundo numero");
		
		x = a + b;
		
		if(x>= 10) {
			System.out.println("o valor da soma � maior ou igual a 10 | valor igual a " + x);
			
		} else if(x <= 10) {
			
			System.out.println("o valor da soma � menor ou igual a 10 | valor igual a " + x);
			
		} else {
			
			System.out.println("o valor da soma � igual " + x);
			
			
		}
		
	}
	
}
