package controller;

import util.*;

public class condicional {
	
	public static void main(String[] args) {
		int a,b,x;
		a = Teclado.Lerint("Informe o primeiro numero");
		b = Teclado.Lerint("Informe o segundo numero");
		
		x = a + b;
		
		if(x> 10) {
			System.out.println("o valor da soma � maior que 10 | valor igual a " + x);
			
		} else if(x < 10) {
			
			System.out.println("o valor da soma � menor que 10 | valor igual a " + x);
			
		} else {
			
			System.out.println("o valor da soma � igual " + x);
			
			
		}
		
	}
	

}
