package controller;

public class ExemplodeVetor {


	public static void main(String[] args) {
		int numeros[] = new int[4];
		 numeros[0] = 6 ;
		 numeros[1] = 10 ;
		 numeros[2] = 33 ;
		 numeros[3] = 17 ;
	
		System.out.println("numeros[0] = " + numeros[0] );
		System.out.println("numeros[1] = " + numeros[1] );
		System.out.println("numeros[3] = " + numeros[2] );
		System.out.println("numeros[4] = " + numeros[3] );
	}	
	
}
